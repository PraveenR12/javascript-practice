//console.log('If Statement')
// let age=prompt('Enter your age')
// if(age >18)
// {
//     console.log('You are Elegiable for Employement')
// }


console.log('Else Statement')
if(age >18)
    {
        console.log('You are Elegiable for Employement')
    }
    else
    {
        console.log('You are not Elegiable for Employement')
    }

//console.log('If Else If Statement')
// let a=10;b=50;c=200;
// if(a > b && a > c)
//     {
//         console.log('a is greater')
//     }
// else if(b > c)
//     {
//         console.log('b is greater')
//     }
// else
//     console.log('c is greater')



//console.log('Multiple Else If Statement')
// let mark=prompt('Enter your mark')

//     if(mark >= 35 && mark < 50)
//         {
//             console.log('Pass with  Third class')
//         }
//     else if(mark >= 50 && mark < 60)
//         {
//             console.log('Pass with  Second class')
//         }
//     else if(mark >= 60 && mark < 60)
//         {
//             console.log('Pass with  First class')
//         }
//     else if(mark >= 60 && mark <=100)
//         {
//             console.log('Pass with Distinction  class')
//         }
//     else
//         {
//             console.log('Fail')
//         }


// console.log(' Switch Case Statement')
// let s=prompt("Please enter a value");

// switch(Number(s))
// {
//    case 12:
//     console.log("1 Dozen");
//        break;
//    case 24:
//     console.log("2 Dozen");
//        break;
//    case 36:
//     console.log("3 Dozen");
//        break;
//    case 48:
//     console.log("4 Dozen");
//        break;
//    default:
//     console.log("Default");
//        break;
// }


// console.log(' Multiple Switch Case Statement')
// let s=prompt("Please enter a value");
// switch(Number(s))
// {
//     case 3:
//     case 6:
//     case 9:
//     case 12:
//         console.log("1 Dozen");
//         break;
//    case 24:
//         console.log("2 Dozen");
//         break;
//    case 36:
//         console.log("3 Dozen");
//         break;
//    case 48:
//         console.log("4 Dozen");
//         break;
//    default:
//         console.log("Default");
//         break;
// }





--------------------------------

// console.log('For Loop')
// for (let i = 0; i < 5; i++)
// {
//    console.log( "John")
// }

// console.log('Print Even no series For Loop')
// for (let i = 0; i < 20; i+=2)
// {
//    console.log(i)
// }

// console.log('Print ODD no series For Loop')
// for (let i = 1; i < 20; i+=2)
// {
//    console.log(i)
// }

// console.log('Using While print the nos 1to 20')
// let i = 0;
// while(i <= 20)
// {
//     console.log(i)
//     i+=2;
// }

// console.log("Print series of 1 to 10 using do while Loop");
// let i = 0;
// do
// {
//    console.log(i);
//    i++;
// }while (i < 10);


// console.log('User defined odd no series  using For Loop')
// let s=prompt('please enter the start value')
// let e=prompt('please enter the end value')
// for (let i = Number(s); i <= Number(e); i+=2)
// {
//    console.log(i)
// }


// console.log('User defined odd no series  using For Loop')
// let s=prompt('please enter the start value')
// let e=prompt('please enter the end value')
// for (let i = Number(s); i <= Number(e); i++)
// {
//     if(i%2!=0)
//    console.log(i)
// }

// console.log('User defined even no series  using For Loop')
// let s=prompt('please enter the start value')
// let e=prompt('please enter the end value')
// for (let i = Number(s); i <= Number(e); i++)
// {
//     if(i%2==0)
//    console.log(i)
// }

// console.log('find the factorial of given no')
// let n=prompt('please enter the value')
// let f=1;
// for(let i=1;i<=n;i++)  //1  2 3 4 5 6
// {
// f=f*i; //f*=i;  // 1 2  6 24 120
// }
// console.log("Factorial of "+ n + " = " + f)
// console.log(` Factorial of ${n} = ${f} `)




// console.log('find the factorial of given no')
// let n=prompt('please enter the value')
// let f=1;
// for(let i=n;i>=1;i--)  // 5 4 3 2 1
// {
// f=f*i; //f*=i;  // 5 20 60 120 120
// }
// console.log("Factorial of "+ n + " = " + f)
// console.log(` Factorial of ${n} = ${f} `)



let message = document.getElementById("heading")
message.innerHTML = "welcome"

function praveen(){
    let num1 = Number(document.getElementById("input1").value)
    let num2 = Number(document.getElementById("input2").value)
    let add = num1+num2
    let result = document.getElementById("result")
    result.innerHTML = "Addition =" + add
}

function convert(){
    let cmVal = Number(document.getElementById("input").value)
    let incVal = cmVal/2.54
    let re = document.getElementById("re")
    re.innerHTML = incVal +"inches"
}

let str1 = "my name is Barani Priya"
let str2 = "I am a software Developer"
console.log(str1+str2)
console.log(str1.concat(str2))
console.log(str1.concat(". ",str2))
//partitioning String
/* 
slice(start,end)
subString(start , end)
substr(start , length)
*/
console.log(str2.slice(4,10))//start value included stop value excluded
console.log(str2.slice(5))
console.log(str2.slice(-1))
console.log(str2.slice(-5))
console.log(str2.substring(4,10))
console.log(str2.substr(4,10))

console.log(str1.replace("Barani Priya","Praveen Styne"))
console.log(str1.toUpperCase())
console.log(str1.toLowerCase())
console.log(str1.length)
console.log(str1.trim())
console.log(str1.trimEnd())
console.log(str1.trimStart())


let bill = "Rs.10"
console.log(bill.length)
console.log(bill.padEnd(7,"0"))
console.log(str1[6])
console.log(str1.charAt(6))
console.log(str1.charCodeAt(6))
console.log(str1.indexOf('a'))
console.log(str1.lastIndexOf("a"))
console.log(str1.lastIndexOf("z"))

console.log(str1.search("ni"))
console.log(str1.search("Ni"));

console.log(str1.includes("ni"))

console.log(str1.startsWith("n"))
console.log(str1.endsWith("a"));

